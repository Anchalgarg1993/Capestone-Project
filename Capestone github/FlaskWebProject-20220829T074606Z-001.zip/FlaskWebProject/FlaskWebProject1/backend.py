import pandas as pd
import numpy as np
import yfinance as yf
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
from matplotlib import pyplot as plt
import ssl

import warnings
warnings.filterwarnings("ignore")

import riskfolio as rp

import time

# set the max columns to none
pd.set_option('display.max_columns', None)





def closing_dataset_funtion(tickers,start,end):
    df = yf.download(tickers, start=start, end=end,progress=False,show_errors=False)['Close']
    return df


def RSI_dataset_function(dataset,n2=14):
    close_price = dataset.copy()
    
    for i in close_price:
        a = pd.DataFrame(close_price[i])
        
        # Omtting null values
        a = a.dropna(axis=0)
        
        change = a.diff().dropna()
        change
       
        change_up = change.clip(lower=0)
        
        change_down = (-1 * change.clip(upper=0)).abs()
        

        avg_up = change_up.rolling(n2).mean()
    
        avg_down = change_down.rolling(n2).mean().abs()

        rs = avg_up/avg_down   # calculating rs
        
        rsi = 100-(100/(1+rs))  # calculating RSI
        
        rsi.dropna(inplace=True)
        close_price[i] = rsi
    
    return close_price

def SMA_dataset_function(dataset,n=5):
    close_price = dataset.copy()
    return close_price.rolling(n).mean()

### Function to get the Linear Regression Slopes
def regr(x,y):
    regr1 = LinearRegression()
    regr1.fit(x,y)
    return regr1.coef_

def get_Slope(dataset): ## Input would be the Dataset
    close_price = dataset.copy()
    index_list = []
    regr2 = []   ### Empty list to store the slope of the input dataset.
    y_hat = close_price ### Defining y_hat which is same as dataset.
    y_hat = y_hat.reset_index(drop=True)    ### Resetting the index so that date becomes a column.

    for i in y_hat.columns[1:]:   #### Iterating through the columns of y_hat.
        y = y_hat[i]   ### y is taken as the each data point of each and every column.
        y.dropna(inplace=True)
        if len(y)>0:
            x = np.array(y.index).reshape(-1, 1)   ##The x axis taken as sequence of numbers. 
            regr2.append(regr(x,y))   ## Appending the coefficients to the empty list.
            index_list.append(i)
    return pd.DataFrame(regr2, index = index_list)   ### Return the Dataframe and the index is set as column names.
# get_Slope(RSI_dataset[-40:-10]) ### Calling the function.



def RSI_divergence_function(SMA_dataset,RSI_dataset):
    SMA_slope = get_Slope(SMA_dataset)
    SMA_slope.rename(columns={0:'SMA'},inplace=True)
    RSI_slope = get_Slope(RSI_dataset)
    RSI_slope.rename(columns={0:'RSI'},inplace=True)
    divergence = pd.concat([SMA_slope,RSI_slope],axis=1)
    divergence['divergence'] = True

    for i in range(len(divergence)):
        if not (divergence.iloc[i][0] < 0) & (divergence.iloc[i][1]>0):
            divergence.divergence.iloc[i] = False
    return divergence

def RSI_breakout_function(new_RSI_dataset,breakout_RSI_dataset): 
    """
    input: two RSI dataset which is broken in two windows
    """
     # taking the last value of both the windows
    new_RSI_dataset = new_RSI_dataset[-1:]
    breakout_RSI_dataset = breakout_RSI_dataset[-1:]
    
    # checking the last value of the last window is lesser than the latest window
    RSI_breakout = pd.DataFrame(new_RSI_dataset.iloc[0] < breakout_RSI_dataset.iloc[0])
    
    # changing the name of the column
    RSI_breakout.rename(columns={0:'RSI_breakout'},inplace=True)
    
    # returning RSI_breakout
    return RSI_breakout


def breakout_function(dataset,breakout_window = 10,RSI_divergence_window = 30):
    close_price = dataset.copy()
#     print(dataset.shape)
    
    # tries to two dataset which is RSI and SMA
    RSI_dataset = RSI_dataset_function(close_price)
    SMA_dataset = SMA_dataset_function(close_price)
#     print(RSI_dataset.shape)
#     print(SMA_dataset.shape)
    
    
    # Breaking the Dataset into Two Windows 
    
    # RSI DIVERGENCE WINDOW
    new_RSI_dataset = RSI_dataset[-RSI_divergence_window-breakout_window:-breakout_window]
    new_SMA_dataset = SMA_dataset[-RSI_divergence_window-breakout_window:-breakout_window]
#     print(new_RSI_dataset.shape)
#     print(new_SMA_dataset.shape)

    # BREAKOUT WINDOW
    breakout_RSI_dataset = RSI_dataset[-breakout_window:]
    breakout_SMA_dataset = SMA_dataset[-breakout_window:]
#     print(breakout_RSI_dataset.shape)
#     print(breakout_SMA_dataset.shape)
    
    # Calculating RSI Divergence
    RSI_divergence = RSI_divergence_function(new_SMA_dataset,new_RSI_dataset)
    
    # Calculating Price Breakout
#     price_breakout = price_breakout_function(new_SMA_dataset,breakout_SMA_dataset)

    # Calculating RSI Breakout
#     RSI_breakout = RSI_breakout_function(new_RSI_dataset,breakout_RSI_dataset)

    
    # Calculating Breakout SMA Slope
    breakout_slope = get_Slope(breakout_SMA_dataset)
    breakout_slope.rename(columns={0:'SMA_breakout'},inplace=True)
    
    # Calculating Breakout SMA Slope
    breakout_RSI_slope = get_Slope(breakout_RSI_dataset)
    breakout_RSI_slope.rename(columns={0:'RSI_breakout'},inplace=True)

    
    # Concatenating all the Dataframes
    breakout = pd.concat([RSI_divergence,breakout_slope,breakout_RSI_slope],axis=1)
    
    # Adding a breakout column with 
    breakout['breakout'] = None
    
#     breakout
    for i in range(len(breakout)):
        if ((breakout.iloc[i][2] == True)and(breakout.iloc[i][3]>0)and breakout.iloc[i][4]>0):
#         if ((breakout.iloc[i][2] == True)and(breakout.iloc[i][3]>0)):            
#             print(i)
#             print(True)
            breakout.breakout[i] = True
    return breakout



#Final Function
def backend_test():
    bse_ticker = pd.read_csv('Master.csv')
    bse_ticker.set_index('NSE Ticker',inplace=True)
    cd = pd.read_csv('closing_dataset.csv',index_col='Date',parse_dates=True)
    para = {
        'OPM':[False,12,'>'],
        'CFO':[True,0,'>'],
        'Net Cash Flow':[False,0,'>']
        }

    para_s = {
        'Financing Margin %':[True,12,'>'],
        'Net_Profit':[True,0,'>'],
        'Net Cash Flow':[False,0,'>']
    }
    tickers = ["RELIANCE.NS","INFY.NS",'AAVAS.NS','AMARAJABAT.NS','3MINDIA.NS','AJANTPHARM.NS','CASTROLIND.NS','CROMPTON.NS','ANURAS.NS','KNRCON.NS','PNBHOUSING.NS']
    start = '2021-01-01'
    end = '2022-05-01'
    breakout_window=10
    RSI_divergence_window = 40

    # Part 1
    start_index = pd.date_range(start=start,end=end)
    dataset = cd.copy()
    closing_dataset = dataset.loc[dataset.index.intersection(start_index)]
    RSI_dataset = RSI_dataset_function(closing_dataset)
    SMA_dataset = SMA_dataset_function(closing_dataset)
    print("Part 1 Done")

    #part 2
    a = breakout_function(closing_dataset,breakout_window=breakout_window,RSI_divergence_window=RSI_divergence_window)
    breakout = a.loc[a['breakout']==True]
    z = list(breakout.index)
    

    print(z)
    breakout['Industry'] = bse_ticker['Industry'].loc[z].values
    print(pd.DataFrame(breakout))

    #print(breakout.index)
    #display(breakout) ######
    #print(breakout.to_json())
    #print(breakout.to_json())
    lst = list(breakout.index)
    #print(lst)
    b = list(bse_ticker.loc[lst]['BSE Ticker'].values)
    #print(b)

    return lst,b,pd.DataFrame(breakout)




def process_data(from_date,to_date,divergence,breakout):
    start = from_date
    end = to_date
    breakout_window=int(breakout)
    RSI_divergence_window = int(divergence)
    print(start, end)
    bse_ticker = pd.read_csv('Master.csv')
    bse_ticker.set_index('NSE Ticker',inplace=True)
    cd = pd.read_csv('closing_dataset.csv',index_col='Date',parse_dates=True)
    para = {
        'OPM':[False,12,'>'],
        'CFO':[True,0,'>'],
        'Net Cash Flow':[False,0,'>']
        }

    para_s = {
        'Financing Margin %':[True,12,'>'],
        'Net_Profit':[True,0,'>'],
        'Net Cash Flow':[False,0,'>']
    }

    

    # Part 1
    start_index = pd.date_range(start=start,end=end)
    dataset = cd.copy()
    closing_dataset = dataset.loc[dataset.index.intersection(start_index)]
    RSI_dataset = RSI_dataset_function(closing_dataset)
    SMA_dataset = SMA_dataset_function(closing_dataset)
    print("Part 1 Done")

    #part 2
    a = breakout_function(closing_dataset,breakout_window=breakout_window,RSI_divergence_window=RSI_divergence_window)
    breakout = a.loc[a['breakout']==True]
    z = list(breakout.index)

    breakout['Industry'] = bse_ticker['Industry'].loc[z].values
    #print(pd.DataFrame(breakout))

    #print(breakout.index)
    #display(breakout) ######
    #print(breakout.to_json())
    #print(breakout.to_json())
    lst = list(breakout.index)
    #print(lst)
    b = list(bse_ticker.loc[lst]['BSE Ticker'].values)
    print(b)

    return pd.DataFrame(breakout)

