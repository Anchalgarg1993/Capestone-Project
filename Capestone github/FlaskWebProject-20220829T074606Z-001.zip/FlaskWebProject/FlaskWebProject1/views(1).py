"""
Routes and views for the flask application.
"""

from datetime import datetime,date
from flask import render_template,request
from FlaskWebProject1 import app
from FlaskWebProject1 import backend
from FlaskWebProject1 import portfol
import pandas as pd
import numpy as np




@app.route('/home')
def home():
    df =  backend.backend_test()
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Inputs:',
        app_name='PortOP',
        year=datetime.now().year,
        markets = ["NSE", "BSE"],
        tables= [df.to_html(classes='data')],
        titles=df.columns.values
    )


@app.route('/')
@app.route('/test')
def test():
    print()
    return render_template(
        'home.html',
        title='Inputs:',
        app_name='PortOP',
        year=datetime.now().year,
        )

@app.route('/update_data', methods=['POST'])
def update_data():
    print("Update Data")
    from_date = request.form['from_date']
    to_date = request.form['to_date']
    divergence = request.form['divergence']
    break_out = request.form['break_out']
    start_year = datetime.strptime(from_date, '%Y-%m-%d').strftime('%b %Y')
    end_year = datetime.strptime(to_date, '%Y-%m-%d').strftime('%b %Y')

    lst,b,closing_dataset,breakout = portfol.part_1(from_date,to_date,int(break_out),int(divergence))
    # backend.process_data(from_date,to_date,divergence,break_out)
    
    filtered_trigger = portfol.part_2(lst,b,start_year,end_year)

    #filter Paramerters
    years = list(filtered_trigger['Year'].values)
    years = list(set(years))
    industry_type =  list(filtered_trigger['Industry'].values)
    industry_type = list(set(industry_type))

    df = filtered_trigger.copy()
    
    """Renders the home page."""
    
    return render_template(
        'index.html',
        title='Inputs:',
        app_name='PortOP',
        year=datetime.now().year,
        markets = ["NSE", "BSE"],
        tables= [df.to_html(classes='data')],
        titles=df.columns.values,
        from_date = from_date,
        to_date = to_date,
        break_out = break_out,
        divergence = divergence,
        filter_years = years,
        industry_type = industry_type,
        tablesOne = [breakout.to_html(classes='data')],
        titlesone= breakout.columns.values,
    )


@app.route('/filter_data', methods=['POST'])
def filter_data():
    print("Filter Data")
    from_date = request.form['from_date']
    to_date = request.form['to_date']
    divergence = request.form['divergence']
    break_out = request.form['break_out']
    start_year = datetime.strptime(from_date, '%Y-%m-%d').strftime('%b %Y')
    end_year = datetime.strptime(to_date, '%Y-%m-%d').strftime('%b %Y')
    first_year = request.form['first_year']
    second_year = request.form['second_year']
    first_industry = request.form['first_industry']
    second_industry = request.form['second_industry']
    sales_data_param = request.form['sales_data_param']
    sales_data = request.form['sales_data']
    opm_data_param= request.form['opm_data_param']
    opm_data= request.form['opm_data']
    profit_data_param = request.form['profit_data_param']
    profit_data = request.form['profit_data']
    cfi_data_param = request.form['cfi_data_param']
    cfi_data = request.form['cfi_data']
    cfo_data_param = request.form['cfo_data_param']
    cfo_data = request.form['cfo_data']
    netcash_data_param = request.form['netcash_data_param']
    netcash_data = request.form['netcash_data']
    debt_asst_data_param = request.form['debt_asst_data_param']
    debt_asst_data = request.form['debt_asst_data']
    total_reven_data_param = request.form['total_reven_data_param']
    total_reven_data = request.form['total_reven_data']
    ttl_liabli_data_param = request.form['ttl_liabli_data_param']
    ttl_liabli_data = request.form['ttl_liabli_data']

    lst,b,closing_dataset,breakout = portfol.part_1(from_date,to_date,int(break_out),int(divergence))
    # backend.process_data(from_date,to_date,divergence,break_out)
    
    filtered_trigger = portfol.part_2(lst,b,start_year,end_year)
    
    #filter Paramerters
    years = list(filtered_trigger['Year'].values)
    years = list(set(years))
    industry_type =  list(filtered_trigger['Industry'].values)
    industry_type = list(set(industry_type))
    selected_years = [first_year,second_year]
    selected_indutry = [first_industry,second_industry]
    df = filtered_trigger.copy()
    

    #Applying Filters
    if(len(first_year)>0):
        df = df[df.Year.isin(selected_years)]

    if(len(first_industry)>0):
        df = df[df.Industry.isin(selected_indutry)]

    if(len(sales_data)>0):
        qry = "Sales {0} {1}".format(sales_data_param,sales_data)
        df = df.query(qry)

    if(len(opm_data)>0):
        qry = "OPM {0} {1}".format(opm_data_param,opm_data)
        df = df.query(qry)

    if(len(profit_data)>0):
        qry = "Net_Profit {0} {1}".format(profit_data_param,profit_data)
        df = df.query(qry)

    if(len(cfi_data)>0):
        qry = "CFI {0} {1}".format(cfi_data_param,cfi_data)
        df = df.query(qry)

    if(len(cfo_data)>0):
        qry = "CFO {0} {1}".format(cfo_data_param,cfo_data)
        df = df.query(qry)

    if(len(netcash_data)>0):
        qry = "Net_Cash_Flow {0} {1}".format(netcash_data_param,netcash_data)
        df = df.query(qry)

    if(len(debt_asst_data)>1):
        qry = "Debt_Asset {0} {1}".format(debt_asst_data_param,debt_asst_data)
        df = df.query(qry)

    if(len(total_reven_data)>0):
        qry = "Total_Revenue {0} {1}".format(total_reven_data_param,total_reven_data)
        df = df.query(qry)


    selected_shares = list(df.index)
    selected_shares = list(set(selected_shares))
    

    #final_dataset = portfol.part_4(selected_shares,closing_dataset)
    #print('final_dataset')
    #print(final_dataset)
    
    """Renders the home page."""
    
    return render_template(
        'index.html',
        title='Inputs:',
        app_name='PortOP',
        year=datetime.now().year,
        markets = ["NSE", "BSE"],
        tables = [df.to_html(classes='data')],
        titles=df.columns.values,
        from_date = from_date,
        to_date = to_date,
        break_out = break_out,
        divergence = divergence,
        filter_years = years,
        industry_type = industry_type,
        is_processed = True,
        selected_shares = selected_shares,
        is_final = False,
        #finaltables = [final_dataset.to_html(classes='data')],
        #finaltitles=final_dataset.columns.values,
        tablesOne = [breakout.to_html(classes='data')],
        titlesone= breakout.columns.values,
        first_year_data = first_year,
        second_year_data = second_year,
        first_industry_data = first_industry,
        second_industry_data = second_industry,
        sales_data_param = sales_data_param,
        sales_data = sales_data,
        opm_data_param= opm_data_param,
        opm_data= opm_data,
        profit_data_param = profit_data_param,
        profit_data = profit_data,
        cfi_data_param = cfi_data_param,
        cfi_data = cfi_data,
        cfo_data_param = cfo_data_param,
        cfo_data = cfo_data,
        netcash_data_param = netcash_data_param,
        netcash_data = netcash_data,
        debt_asst_data_param = debt_asst_data_param,
        debt_asst_data = debt_asst_data,
        total_reven_data_param = total_reven_data_param,
        total_reven_data = total_reven_data,
        ttl_liabli_data_param = ttl_liabli_data_param,
        ttl_liabli_data = ttl_liabli_data
 
    )


@app.route('/final_data', methods=['POST'])
def final_data():
    print("Final Data")
    print("Filter Data")
    from_date = request.form['from_date']
    to_date = request.form['to_date']
    divergence = request.form['divergence']
    break_out = request.form['break_out']
    start_year = datetime.strptime(from_date, '%Y-%m-%d').strftime('%b %Y')
    end_year = datetime.strptime(to_date, '%Y-%m-%d').strftime('%b %Y')
    first_year = request.form['first_year']
    second_year = request.form['second_year']
    first_industry = request.form['first_industry']
    second_industry = request.form['second_industry']
    sales_data_param = request.form['sales_data_param']
    sales_data = request.form['sales_data']
    opm_data_param= request.form['opm_data_param']
    opm_data= request.form['opm_data']
    profit_data_param = request.form['profit_data_param']
    profit_data = request.form['profit_data']
    cfi_data_param = request.form['cfi_data_param']
    cfi_data = request.form['cfi_data']
    cfo_data_param = request.form['cfo_data_param']
    cfo_data = request.form['cfo_data']
    netcash_data_param = request.form['netcash_data_param']
    netcash_data = request.form['netcash_data']
    debt_asst_data_param = request.form['debt_asst_data_param']
    debt_asst_data = request.form['debt_asst_data']
    total_reven_data_param = request.form['total_reven_data_param']
    total_reven_data = request.form['total_reven_data']
    ttl_liabli_data_param = request.form['ttl_liabli_data_param']
    ttl_liabli_data = request.form['ttl_liabli_data']

    lst,b,closing_dataset,breakout = portfol.part_1(from_date,to_date,int(break_out),int(divergence))
    # backend.process_data(from_date,to_date,divergence,break_out)
    
    filtered_trigger = portfol.part_2(lst,b,start_year,end_year)
    
    #filter Paramerters
    years = list(filtered_trigger['Year'].values)
    years = list(set(years))
    industry_type =  list(filtered_trigger['Industry'].values)
    industry_type = list(set(industry_type))
    selected_years = [first_year,second_year]
    selected_indutry = [first_industry,second_industry]
    df = filtered_trigger.copy()
    

    #Applying Filters
    if(len(first_year)>0):
        df = df[df.Year.isin(selected_years)]

    if(len(first_industry)>0):
        df = df[df.Industry.isin(selected_indutry)]

    if(len(sales_data)>0):
        qry = "Sales {0} {1}".format(sales_data_param,sales_data)
        df = df.query(qry)

    if(len(opm_data)>0):
        qry = "OPM {0} {1}".format(opm_data_param,opm_data)
        df = df.query(qry)

    if(len(profit_data)>0):
        qry = "Net_Profit {0} {1}".format(profit_data_param,profit_data)
        df = df.query(qry)

    if(len(cfi_data)>0):
        qry = "CFI {0} {1}".format(cfi_data_param,cfi_data)
        df = df.query(qry)

    if(len(cfo_data)>0):
        qry = "CFO {0} {1}".format(cfo_data_param,cfo_data)
        df = df.query(qry)

    if(len(netcash_data)>0):
        qry = "Net_Cash_Flow {0} {1}".format(netcash_data_param,netcash_data)
        df = df.query(qry)

    if(len(debt_asst_data)>1):
        qry = "Debt_Asset {0} {1}".format(debt_asst_data_param,debt_asst_data)
        df = df.query(qry)

    if(len(total_reven_data)>0):
        qry = "Total_Revenue {0} {1}".format(total_reven_data_param,total_reven_data)
        df = df.query(qry)


    selected_shares = list(df.index)
    selected_shares = list(set(selected_shares))
    

    final_dataset = portfol.part_4(selected_shares,closing_dataset)
    #print('final_dataset')
    #print(final_dataset)
    
    return render_template(
        'index.html',
        title='Inputs:',
        app_name='PortOP',
        year=datetime.now().year,
        markets = ["NSE", "BSE"],
        tables = [df.to_html(classes='data')],
        titles=df.columns.values,
        from_date = from_date,
        to_date = to_date,
        break_out = break_out,
        divergence = divergence,
        filter_years = years,
        industry_type = industry_type,
        is_processed = True,
        selected_shares = selected_shares,
        is_final = True,
        finaltables = [final_dataset.to_html(classes='data')],
        finaltitles=final_dataset.columns.values,
        tablesOne = [breakout.to_html(classes='data')],
        titlesone= breakout.columns.values,
        first_year_data = first_year,
        second_year_data = second_year,
        first_industry_data = first_industry,
        second_industry_data = second_industry,
        sales_data_param = sales_data_param,
        sales_data = sales_data,
        opm_data_param= opm_data_param,
        opm_data= opm_data,
        profit_data_param = profit_data_param,
        profit_data = profit_data,
        cfi_data_param = cfi_data_param,
        cfi_data = cfi_data,
        cfo_data_param = cfo_data_param,
        cfo_data = cfo_data,
        netcash_data_param = netcash_data_param,
        netcash_data = netcash_data,
        debt_asst_data_param = debt_asst_data_param,
        debt_asst_data = debt_asst_data,
        total_reven_data_param = total_reven_data_param,
        total_reven_data = total_reven_data,
        ttl_liabli_data_param = ttl_liabli_data_param,
        ttl_liabli_data = ttl_liabli_data
        )